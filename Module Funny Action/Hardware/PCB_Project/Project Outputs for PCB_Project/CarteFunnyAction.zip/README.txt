Coupe de France de Robotique
1 exemplaire
Jean-marc.capron@yncrea.fr
Arthur.duytschaever@isen.yncrea.fr
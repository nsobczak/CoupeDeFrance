Carte Detection 
Projet Coupe de France de Robotique 
1 exemplaire 
Jean-Marc.capron@yncrea.fr
Arthur.duytschaever@isen.yncrea.fr
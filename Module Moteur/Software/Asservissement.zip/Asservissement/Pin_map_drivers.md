# Pin Map Shield Moteur

# Drivermoteur gauche :
pwm - 6
IN1 - 52
IN2 - 53

# Drivermoteur Droit :
pwm - 3
IN1 - 22
IN2 - 23

# Encoder Gauche :
pinA - 13
pinB - 12

# Encoder Droit : 
pinA - 11
pinB - 10
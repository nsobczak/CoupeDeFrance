# ReadArduinoSerial

ReadArduinoSerial is an application which writes information received on the serial port in a csv file. <br/>
Application developed in java.

(works only on windows, problem unsloved with linux)

> src.app is the package which contains the code to send data

> src.sample is the package which contains the code to read data

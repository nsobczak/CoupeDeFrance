Projet Coupe De France
1 exemplaire 
Jean-marc.capron@yncrea.fr
Arthur.duytschaever@isen.yncrea.fr

Projet coupe de france
8*3 cm 
6 exemplaire 
Arthur.duytschaever@isen.yncrea.fr
Jean-marc.capron@isen.fr

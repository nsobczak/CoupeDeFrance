# Module moteur

Il s'agit du dossier destiné à accueillir tout ce qui concerne la carte les moteurs servant à faire rouler le robot.

## Description des dossiers

Ce dossier est composé de 2 sous-dossiers :

- Hardware : dossier contenant toute la partie hardware des moteurs, comme la carte driver par exemple.
- Software : dossier contenant toute la partie sorftware des moteurs, comme l'asservissement par exemple.
